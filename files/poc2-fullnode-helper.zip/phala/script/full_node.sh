#!/bin/bash

NODE_NAME="phala node anonymous"
WORK_PATH=$(dirname $(dirname $(readlink -f "$0")))
BASE_PATH_BASE="$HOME/data/$NODE_NAME"
CHAIN_NAME="phala"
WASM_EXECUTION_MODE="Compiled" # Interpreted
BOOT_NODES="/ip4/139.180.155.4/tcp/31333/p2p/12D3KooWR8Bce8DGTtRgf8gmYg9Xx5RwQoSv41pXAYWeJfXtwF6z /ip4/45.77.47.160/tcp/32333/p2p/12D3KooWPGTpv1dg9EBUgJuiMFU3gKExYj7nnRqKF7wrhHtYFR3c /ip4/45.77.47.160/tcp/33333/p2p/12D3KooWHrLP1wgd7qdsRLbYZXzcsoAWPFq5wfwqHrJoHNdByi4w /ip4/45.77.47.160/tcp/34333/p2p/12D3KooWGeRRK2WzXQeUi931fcvF3NGi2nRFZatL7DG3CmkQfjWy"

$WORK_PATH/phala-node \
  --chain $CHAIN_NAME \
  --base-path $BASE_PATH_BASE \
  --database paritydb \
  --wasm-execution $WASM_EXECUTION_MODE \
  --name $NODE_NAME \
  --pruning archive \
  --rpc-cors all \
  --rpc-port 9933 \
  --ws-port 9944 \
  --bootnodes $BOOT_NODES \
  "$@"
